#include <iostream>

int main() {
    //matriz 1
int fila, columna,i,j;
    printf("ingrese el numero de filas: ", &fila);
    printf("ingrese numero columnas: ", &columna);

    int matriz[fila][columna];

    //ingresar datos matriz 1
    for (i=0; i<=fila-1; i++) {
        for (j = 0; j <= columna - 1; j++) {
            scanf("ingrese el numero en la posicion [%i]: ", i, &matriz[i][j]);
        }
    }
    printf(" \n");
// ingresar datos matriz 2
    int matriz2[fila][columna];
    for (i=0; i<=fila-1; i++) {
        for (j = 0; j <= columna - 1; j++) {
            scanf("ingrese el numero en la posicion [%i]: ", i, &matriz2[i][j]);
        }
    }
    printf(" \n");
    //suma
    int matriz3[i][j];
    for (i=0; i<=fila-1; i++) {
        for (j = 0; j <= columna - 1; j++) {
            matriz3[i][j]= matriz[i][j]+matriz2[i][j];
        }
        }
    printf(" \n");
    scanf("resultado suma matrices: ", matriz3[i][j]);
    printf(" \n");
    return 0;
}