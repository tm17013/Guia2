#include <iostream>
#define fila 2
#define columna 2
int main() {
int matriz[fila][columna];
int i,j,x,y,auxiliar;
    printf("llenando matriz: ");
for (i=0; i<fila; i++){
    for(j=0;j<columna;j++){
        printf(" ingrese un numero:");
        scanf("%d",&matriz[i][j]);

    }
}
    printf("matriz desordenada--------: ");
    for (i=0; i<fila; i++){
        for(j=0;j<columna;j++){
            printf(" \n");
            printf(" %d\t",matriz[i][j]);

        }
    }

    //ordenar la matriz de forma descendente//

    for (i=0; i<fila; i++) {
        for (j = 0; j < columna; j++) {
            for (x=0; x<fila; x++) {
                for (y= 0; y < columna-1; y++) {
if (matriz[i][j]>matriz[x][y]){
    auxiliar=matriz[i][j];
    matriz[i][j]= matriz[x][y];
    matriz [x][y]= auxiliar;
}
                }
            }
        }
    }
    printf("\n");
    printf("matriz ordenada--------: ");
    for (i=0; i<fila; i++){
        for(j=0;j<columna;j++){
            printf(" \n");
            printf(" %d\t",matriz[i][j]);

        }
    }
    printf("\n");




    return 0;
}